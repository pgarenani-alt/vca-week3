# VCA Week 3 — BLOCK HUNT

Villanova Blockchain Society · Villanova Crypto Academy · Fall 2026
**Session:** Monday 14 September 2026 — *Bitcoin and Blockchain Mechanics*

Students pull a real Bitcoin block off mempool.space, compute the issuance
schedule, and compare the ETH and SOL fee markets. 3 rounds, 1,000 points,
about 11 minutes. Auto-graded, live leaderboard, CSV export for the 15%
in-session participation score.

- **Student view:** `/`
- **Presenter view:** `/?p=present`

---

## Deploy — Streamlit Community Cloud (free, ~6 minutes)

1. **New GitHub repo** — github.com/new → name `vca-week3` → **Public** → Create.
   (Public is required for the free Streamlit tier.)
2. **Upload these files** — on the empty repo page click **uploading an existing
   file**, drag in the whole unzipped folder's contents (`app.py`,
   `requirements.txt`, the `.streamlit` folder, `Procfile`, `railway.json`,
   `README.md`), then **Commit changes**.
3. **Deploy** — go to **share.streamlit.io** → sign in with GitHub → **Create app**
   → **Deploy a public app from GitHub** → repo `vca-week3`, branch `main`,
   main file `app.py` → **Deploy**. First build takes 2–4 minutes.
4. **Get the URL** — it will look like `https://vca-week3.streamlit.app`.
5. **Open the presenter view** — append `/?p=present` to that URL. Bookmark both.

### Pre-class checklist (2 minutes, do it in the room)
1. Open the presenter view. Click **Fetch live from mempool.space + CoinGecko**.
2. Check the ETH base fee against etherscan.io/gastracker and type it in.
3. Click **LOCK THESE NUMBERS**. The banner must read *Currently locked*.
4. Paste your app URL into the **Student play URL** box → a QR appears → project it.
5. Switch to the **Live board** tab and leave it on the projector.

> **Why the lock matters.** A new Bitcoin block lands every ~10 minutes and the
> activity runs ~11. Without a lock, a student answering in minute 2 and one
> answering in minute 9 would be reading different blocks and one of them would
> be marked wrong. The lock freezes one block for the whole room.

---

## Fallback — Railway (if Streamlit Cloud is down or you want no sleep timer)

The repo already contains `Procfile` and `railway.json`.

1. railway.app → **New Project** → **Deploy from GitHub repo** → pick `vca-week3`.
2. Railway auto-detects Python via Nixpacks and uses the start command in
   `railway.json`. No environment variables required.
3. **Settings → Networking → Generate Domain** to get a public URL.
4. Paste that URL into the presenter view's QR box.

Railway's free trial credit covers a session like this; Hobby is $5/month.
Streamlit Community Cloud is free indefinitely but sleeps after ~7 days of
inactivity and takes ~30 seconds to wake — **open the app once an hour before
class** so students never see a cold start.

---

## Run of show (11 minutes)

| | Time | What you say / do |
|---|---|---|
| Setup | 1:00 | QR on screen. "Phones out. Second tab on mempool.space." |
| Round 1 · The Block | 4:00 | They read block #X off the explorer. 400 pts. |
| Round 2 · The Schedule | 3:30 | Pure arithmetic — halving countdown and inflation rate. 350 pts. |
| Round 3 · The Fee Market | 3:30 | EIP-1559 burn, ETH vs SOL fee, one written line. 250 pts. |
| Debrief | 2:00 | Answer key tab. Read two or three Q12 lines out loud. |

The three points the activity exists to land:

1. Miner revenue is still ~98–99% newly printed coins — **Bitcoin's security is
   paid for by dilution of existing holders**, not by the people using it.
   (This is the Week 3 concept from the curriculum: *issuance as a cost borne by
   existing holders*.)
2. **Hashrate does not change issuance.** Difficulty re-targets every 2,016
   blocks. More hashrate buys more security at the same coin cost.
3. **Three chains, three ways to charge for blockspace.** BTC pays the miner,
   ETH burns the base fee and tips the validator, SOL prices it near zero.
   Week 6 turns this into fees vs. revenue.

---

## Scoring

| Round | Points | Questions |
|---|---|---|
| 1 · The Block | 400 | subsidy, total fees, tx count, fee share of miner revenue |
| 2 · The Schedule | 350 | blocks to halving, annual issuance, inflation %, hashrate MCQ |
| 3 · The Fee Market | 250 | base fee destination, ETH transfer cost, SOL fee, written line |

Numeric answers use tolerance bands — full credit inside the band, half credit
inside 2× the band. The **Export** tab converts every score to the 60–100
participation scale automatically (`60 + 40 × score/1000`) and downloads as CSV.

## Reuse for Weeks 4–9

The shell is generic: locked reference values + tolerance-banded numeric entry +
MCQ + one free-text line + auto leaderboard + CSV export. To build Week 4
(unlocks and dilution), replace `answer_key()`, the question bank, and the three
round blocks in `student_view()`. Everything else stays.
